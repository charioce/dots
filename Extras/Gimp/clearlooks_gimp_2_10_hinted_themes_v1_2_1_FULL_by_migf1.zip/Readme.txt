# ---------------------------------------------------------------------
# Clearlooks Gimp 2.10 Hinted Themes v1.2.1
# Author: migf1 (2020)
#
# The themes should work with Gimp 2.8 too, but you may also
# try their older version instead:
# https://www.deviantart.com/migf1/art/Clearlooks-Flat-Icons-Gimp-2-8-Themes-v-1-0-1-484289796
#
# ---------------------------------------------------------------------
# LICENSE:
#
# This theme is Licensed under GNU GPL 2 or later,
# with an additional Attribution term!
#
# Meaning that additionally to all GNU GPL terms, any derivative
# work must be explicitly identified as such, followed by an easily
# accessible link to my DeviantArt account:
# https://www.deviantart.com/migf1
# ---------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this product. If not, see <http://www.gnu.org/licenses/>.
#

==========================================
TABLE OF CONTENTS
==========================================

� Disclaimer
� General Info
� Themes Installation
� Clearlooks GTK2 Theme-Engine Installation
� Selecting Themes From Within Gimp 2.10.1x
� Recommended Icon Themes
� Recovering From Gimp Crashes
� Usage Tips: Editing The gtkrc File
� Support, Fixes & Future Versions
� Release History


==========================================
DISCLAIMER
==========================================

Before anything else, please make sure you have understood the
GNU Public License version 2 (or later) terms for these themes.

Including the additional Attribution term! Meaning that additionally
to all GNU GPL terms, any derivative work must be explicitly identified
as such, followed by an easily accessible link to my DeviantArt account:
    https://www.deviantart.com/migf1

You should have received a copy of the GNU General Public License
version 2 (or later) along with this product. If not, see:
    http://www.gnu.org/licenses/


==========================================
GENERAL INFO
==========================================

ATTENTION
  The themes need the CLEARLOOKS GTK2 theme-engine,
  which is a SEPARATE download. Without it, the themes
  look broken. See the "THEMES INSTALLATION" section,
  further below.

This is an upgrade from my "Clearlooks Flat Icons Gimp 2.8 Themes v.1.0.1",
released back in 2014. If you are interested in those, they are available
on my DeviantArt account:
https://www.deviantart.com/migf1/art/Clearlooks-Flat-Icons-Gimp-2-8-Themes-v-1-0-1-484289796

The new "Clearlooks Gimp 2.10 Hinted Themes" are a complete
re-write, but they look and feel like the old ones. I started them
in Gimp 2.10.18 and finished them in Gimp 2.10.20 (I had so many
requests to update them, so I guess better late than never :)

Gimp 2.10.1x ships with its own flat, monochromatic icons, called
SYMBOLIC and they look great. Aesthetically, my dark themes are
meant to be used with the Symbolic icons, and the light themes
with the Symbolic-Inverted icons, but your mileage may vary.
The themes work with any icons, but for some icon-themes the
icons may become hardly visible.
See the "RECOMMENDED ICON THEMES" section, further below.

However, you still need the CLEARLOOKS theme-engine, which
is NOT shipped with Gimp. See the "THEMES INSTALLATION"
section, further below.

There are DARK and LIGHT themes in the collection (MEDIUM ones
may be added in the future). For each one of them there is an
additional SMALL variant, using smaller font, scrollbars, panel
gaps, etc.
    Dark
    Dark SMALL
    Light
    Light SMALL

Moreover, each variant comes in five (5) COLOR HINT versions:
    Blue
    Orange
    Pink
    Red
    Teal

This makes a total of 20 variations.

So for example, there are 2 dark themes with a blue color-hint:
    Clearlooks Dark (Blue Hints)
    Clearlooks Dark SMALL (Blue Hints)

Similarly for the rest of the themes.

If you are using a 4K monitor, you probably do not want the "Small"
variants, unless you manually tweak the font-size, in their gtkrc
file. See the "USAGE TIPS: EDITING THE gtkrc FILE" section, below.

NOTE that Dark and Lights themes do NOT behave identically, and
that's intentional! See the "SUPPORT, FIXES & FUTURE VERSIONS"
section further below.

These themes are meant to let you focus on your work instead of
distracting you. The color-hints are meant to help you quickly
spot enabled settings inside Gimp's massive User Interface.


==========================================
THEMES INSTALLATION
==========================================

Please note that I am only using Windows now, so I cannot test
the themes on other platforms myself. I did my best to present
the basic requirements for installing them on Linux, and maybe
on macOS/Mac OSX too. The Gimp community has already helped
improving the initial version, and the themes should now look as
intended on Linux too (see the "RELEASE HISTORY" section, below
for links to GImp forums, where you can contribute too).

Also note that the themes need the GTK2 CLEARLOOKS theme-engine
(see the separate section, below).

The themes come packed in a zip-file. Copy all the folders it
contains into one of the Gimp 2.10.1x "themes/" folders.

To see in which folders Gimp looks for themes, go to:
    Edit -> Preferences -> Folders | Themes

Step by Step:
    1. Run Gimp
    2. Open the "Preferences" dialog (menu Edit -> Preferences)
    3. From the tree structure on the left, expand the "Folders" branch
    4. Scroll down and Select the "Themes" leaf
    5. The list of folders where Gimp looks for themes should appear
        on the right pane of the dialog.
    6. Select any of those folders, and its name should appear at the
       top of the list, in between a bunch of icons. The icon on the
       far right opens the selected folder in the file manager of your
       system, for easy access.
    7. Exit Gimp, and copy the themes in that folder.

On MS Windows (64-bit) Gimp looks for themes in 2 folders, namely:
    C:\Users\your-username-here\AppData\Roaming\GIMP\2.10\themes
    C:\Program Files\GIMP 2\share\gimp\2.0\themes\

On GNU/Linux, it should be something like this:
    home/.gimp-2.10/themes

On Mac, it should be something like this:
    /Users/your-username-here/Library/GIMP/2.10/themes

Anyway, do NOT guess! Just follow the steps mentioned above,
and copy the themes in ONE of those folders (preferably to one
that does NOT need admin rights)!

*** WE ARE ALMOST THERE ***

We need to install the Clearlooks engine too!


==========================================
Clearlooks GTK2 THEME-ENGINE INSTALLATION
==========================================

These themes need the GTK2 Clearlooks theme-engine, which is
NOT shipped with Gimp.

On Windows
----------------------
I have bundled a Windows version of the Clearlooks engine, for
both 32-bit & 64-bit architectures, as a separate zip-file (courtesy
of partha: https://www.partha.com/ )

However, DeviantArt does not allow nested zip-files, so I provide
the following link for downloading JUST the Clearlooks engine:

  https://www.mediafire.com/file/oir07denlx4pj7p/win_clearlooks_gtk2_engine.zip/file

Unpack it and read its separate Readme.txt for instructions.

In short, and assuming Gimp is installed in its default folder, you
only need to copy the APPROPRIATE (x64 or x86) libclearlooks.dll
file into the following folder:

    On Windows (64-bit): C:\Program Files\GIMP 2\lib\gtk-2.0\2.10.0\engines
    On Windows (32-bit): C:\Program Files (x86)\GIMP 2\lib\gtk-2.0\2.10.0\engines

On GNU/Linux
----------------------
If you are still using a Gnome 2 (GTK2) theme on your system, then
chances are that the Clearlooks engine is already installed.

But many GTK2 based distros do NOT include it. Also, modern Linux
distros now come with GTK3, which also may not include the engine.

First check if the GTK2 runtime is installed on your system.

For example, on Ubuntu, the following command in the terminal
should show which GTK2 version is installed (you want at least v2.24):
	dpkg -s libgtk2.0-0|grep '^Version'

This command should show all GTK versions on your system:
	dpkg -l libgtk* | grep -e '^i' | grep -e 'libgtk-*[0-9]'

If GTK2 is not installed, do it manually:
	sudo apt-get update
	sudo apt-get install gtk2.0

As far as I know, GTK2 and GTK3 can co-exist on the same system,
but with the gazillion of distros out there you never know.
DO IT AT YOUR OWN RISK.

Then, depending on your distro, look for and install one of the
following packages:
    gtk2-engines
    gtk2-engine-clearlooks
    gtk2-engines-clearlooks

On Ubuntu, it's done with 2 commands in the terminal:
    sudo apt-get update
    sudo apt-get install gtk2-engines

Note that the "gtk2-engines" package contains many GTK2 engines,
not just Clearlooks. It is probably a good idea to go for it, just
in case other Gimp themes need one of those. Gimp currently ships
with only 2 engines: pixmap and wimp.

On MacOS / OS X
----------------------
I am sorry, but I really have no idea about Macs. I found a couple
of links that might be helpful, but I doubt it since they look rather
old:

    1. GTK2: http://www.nongnu.org/bibledit/gtk2_mac_osx.html
    2. Clearlooks:  http://hints.macworld.com/article.php?story=20080309171359879

Maybe, just maybe, these links along with the GNU/Linux section
above can help you make the themes work. You may also have to
install X11 for Mac, from XQuartz: https://www.xquartz.org/ 
I really have no clue!


==========================================
SELECTING THEMES FROM WITHIN GIMP 2.10.1X
==========================================

1. Run Gimp 2.10.1x

2. Select the menu command: Edit -> Preferences

3. In the dialog that pops up, select: "Theme" from the tree
   on the left, then select the desired theme from the list
   on the right.

4. Close the dialog by clicking on its "OK" button.

5. The new theme may be partially displayed on-the-fly,
   but you really need to quit Gimp and re-launch it.


==========================================
RECOMMENDED ICON THEMES
==========================================

Gimp 2.10.1x ships with great, flat monochromatic icons, called
Symbolic (there are a few colored ones too).

Icon-themes can be loaded independently of themes, via:
    Edit -> Preferences | Interface | Icon Theme

However, not all icon-themes are suitable for all themes. There
should always be enough contrast between the icons and the
background of the theme (else the icons may become hardly
visible, or not visible at all).

The recommended icon-themes to be used with my themes are
the following:

for Dark themes:
    Symbolic icons
    Symbolic-High-Contrast icons

for Light themes:
    Symbol-Inverted icons
    Symbolic-Inverted-High-Contrast icons

Feel free to also experiment with other icon-themes.


==========================================
RECOVERING FROM GIMP CRASHES
==========================================

Sometimes a theme may crash Gimp on startup. Try re-launching
it for a few times. If it keeps crashing, locate the folder of the
current theme, and rename the gtkrc file in it to something else
(for example, rename it to: gtkrc-off).

Re-launch Gimp. If the theme was indeed the cause of the crash,
Gimp will start this time, but using a default fall-back theme. You
can then switch to another theme (Edit -> Preferences | Theme).


==========================================
USAGE TIPS: EDITING THE gtkrc FILE
==========================================

Each of these themes is just a folder, named after the theme. The
folder contains a gtkrc file, which you can edit with any text-editor.

NOTE:
    You should use a plain text editor, not a word-processor, else
    you may screw the file up on Save! In any case, keep a backup
    copy of the original.

I have included lots of comments in the gtkrc files (starting with #
or enclosed in /* */), hopefully making it a little easier for anyone
wishing to experiment on their own.

This section will show you a few lines you can edit in the gtkrc file,
to further improve your experience with the themes.

1. If you are using a 4K monitor, you will probably need to set a
    much larger font-size (this will also increase most of the other
    elements too).

    Find and edit these 2 lines, in the gtkrc file:

        gtk-font-name = "Sans 7"
        font_name = "Sans 8.1"

    You only need to change the numeric values, but feel free to
    also specify a font family different than Sans (provided that
    the new font exists on your system already).

2.	These themes do not use icons inside menus and buttons.
    If you want them, replace 0 with 1 in the following lines:

        gtk-menu-images = 0
        gtk-button-images = 0

3. If you do not like any of the hint-colors provided by the themes,
    you can set your own by replacing the hex code in the following
    line:

        gtk_color_scheme = "hl_color:#3380B3"	# Current Highlight Color

    For example, to set a Golden Rod hint-color, replace #3380B3
    with #DAA520 in that line.

    Even better, you can use plain color names, as defined by the
    X11 standard: https://en.wikipedia.org/wiki/X11_color_names

    Try this:
        gtk_color_scheme = "hl_color:Golden Rod"	# Current Highlight Color

    NOTE that plain color name are NOT prefixed by the sharp sign (#).
    "hl_color:Golden Rod" VS "hl_color:#DAA520"


==========================================
SUPPORT, FIXES & FUTURE VERSIONS
==========================================

I am aware of some inconsistencies in the themes. For example,
check/radio buttons do not have consistent looks everywhere.
Same goes for the tree expander arrow & label.

Most of those inconsistencies have to do either with my limited
GTK2 knowledge, or with bugs/omissions in the theme-engine. The
rest are mostly due to my decision that the themes look good
enough already, so I should release them and probably come back
for fixes at a later time (with an updated version).

That said, please understand that I cannot commit to keep
supporting this project. It's fun and everything, but it is
just that: a FUN project. I'm not even a regular Gimp user.

As long as I keep having fun, I'll spend some more of my free
time, trying to fix any issues and/or to implement any suggestions.
However, no promises, no guarantees!

Lastly, Dark and Lights themes do NOT behave identically, and
that's intentional!

For example, in the Light themes, by clicking on a spin button
to change it's attached value, the background of the button gets
highlighted. In the Dark themes however, it is not the button
background that gets highlighted; it is the arrow itself.

Directly translating the behavior of a Dark theme to its Light
counterpart (or vice versa), very rarely gives nice results (well,
according to my standards anyway).

For similar reasons, the highlighting colors (color-hints) are
not exactly the same between Dark and Light themes (Light themes
use lighter shades).

==========================================
RELEASE HISTORY
==========================================

v1.2.1:
�	Thanks to the Gimp community, the themes should now run
	as intended on most Linux distros.

	For details see the following forum topics:
	1. (gimp-forum.net): https://bit.ly/3dzXp9C
	2. (gimpchat.com):  https://bit.ly/31gV2Gp

v1.2:
�	Initial Release (tested on Windows)