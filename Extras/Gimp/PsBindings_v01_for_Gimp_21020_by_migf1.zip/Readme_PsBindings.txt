﻿# ---------------------------------------------------------------------
# Photoshop Bindings v0.1 for Gimp 2.10.20
# Author: migf1 (2020)
#
# ---------------------------------------------------------------------
# LICENSE:
#
# This product is Licensed under GNU GPL 2 or later,
# with an additional Attribution term!
#
# Meaning that additionally to all GNU GPL terms, any derivative
# work must be explicitly identified as such, followed by an easily
# accessible link to my DeviantArt account:
# https://www.deviantart.com/migf1
# ---------------------------------------------------------------------
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this product. If not, see <http://www.gnu.org/licenses/>.
#

==========================================
TABLE OF CONTENTS
==========================================

•  Disclaimer
•  Info & Setup
•  Restoring Prior Bindings
•  Bindings Reference
   ⇢  On-line Reference (COMPLETE LIST)
   ⇢  Mouse Bindings
   ⇢  Key Bindings (INCOMPATIBILITIES RATIONALE)
•  Bindings Customization
•  Support, Fixes & Future Versions
•  Release History


==========================================
DISCLAIMER
==========================================

Before anything else, please make sure you have understood the
GNU Public License version 2 (or later) terms for these themes.

Including the additional Attribution term! Meaning that additionally
to all GNU GPL terms, any derivative work must be explicitly identified
as such, followed by an easily accessible link to my DeviantArt account:
    https://www.deviantart.com/migf1

You should have received a copy of the GNU General Public License
version 2 (or later) along with this product. If not, see:
    http://www.gnu.org/licenses/


==========================================
INFO & SETUP
==========================================

Switching from Photoshop to Gimp can be challenging. These
bindings convert more than 120 Gimp 2.10.20 keyboard shortcuts
to Photoshop CC 2018 (or later) equivalents, or to reasonably
close ones.

They also change the mouse behavior, but besides zooming by
scrolling the wheel without needing the Ctrl key, the rest of
the changes do NOT really match Ps. However, they'll hopefully
make your life a little easier regardless.

The bindings are theme agnostic, meaning they work with any
Gimp theme. However, you may want to check out my themes at
the following link:

	Clearlooks Gimp 2.10 Color Hinted Themes
	https://bit.ly/3eLwQjx

I think they make Gimp look & feel a bit more like Photoshop
compared to the default themes.

SETUP
-------------------------------------------

You only need to replace the following files in Gimp's configuration
folder, with the ones found inside the PsBindings.zip file:
•  menurc
•  controllerrc

YOU PROBABLY WANT TO GET BACKUP COPIES FIRST!

NOTE: In the PsBindings.zip, they're packed inside a "bindings_files" folder:
•  bindings_files\menurc
•  bindings_files\controllerrc

Just copy them individually in Gimp's configuration folder.

Gimp's configuration folder may be hidden, so first make sure your
file manager is set to show hidden items:
    on Windows: https://bit.ly/38cTkr1
    on Linux: https://bit.ly/3i5TYv5
    on macOS: https://bit.ly/2YFRQTb

To locate Gimp's configuration folder, run Gimp and go to:
    Edit -> Preferences -> Folders -> Brushes

If only 1 folder gets listed on the right, select it. If there is more,
select one that resides inside your user-profile folder.

Then click on the icon at the far right, right above the listed folders.
Its mouse-hover label should say: "Show file location in the file manager".

This should open a new window, targeting Gimp's configuration
folder. Notice that you do NOT want the "brushes\" sub-folder,
you want its PARENT folder.

Normally, that folder should be something similar to the following:

On Windows:
  C:\Users\[your-username]\AppData\Roaming\GIMP\2.10

On macOS:
  /Users/[your-username]/Library/Application Support/GIMP/2.10

On Linux (if Gimp installed from repository):
  ~/.config/GIMP/2.10

On Linux (if Gimp installed from Flatpak):
  ~/.var/app/org.gimp.GIMP/config/GIMP/2.10

On Linux (if Gimp installed from Snap):
  ~/snap/gimp/current/.config/GIMP/2.10

Close Gimp, replace the files mentioned above, and you are done!

==========================================
RESTORING PRIOR BINDINGS
==========================================

To reset the keyboard-shortcuts to their default values, exit Gimp
and delete the menurc file (Gimp will re-create it on next run).

Alternatively ( https://imgur.com/TvcM0Ad ):
  Edit -> Preferences -> Interface  [Reset Keyboard Shortcuts to Default Values]

To reset the mouse, exit Gimp and delete the controllerrc file
(Gimp will re-create it on next run).

Prior customizations cannot be restored, UNLESS you had BACKED UP
the files menurc and controllerrc before replacing them. Go into
Gimp's configuration folder and replace those files with your
backed up ones.

==========================================
BINDINGS REFERENCE
==========================================

Ps and Gimp differ in many ways. Lots of Ps functions do not have
Gimp equivalents, and vice versa. That said, I have modified more
than 120 Gimp keyboard shortcuts, and a few mouse bindings.

This is a huge list to include in a Readme file, so I keep it
on-line as a Google Sheet:

	COMPLETE LIST:  https://bit.ly/3dOJvka

To navigate in the Sheet, you can use the scrollbars, or the
Page Up/Down keys, or the arrow-keys on your keyboard.

You can also JUMP to sections, shown in BLUE at the top-right
of the Sheet. Hover your mouse over any of them, and in the
label that pop up, click the PSBindings!Xxxx link

The following ScreenShot shows such a link for the Filters section:

	ScreenShot: https://imgur.com/ET4oVyD

From the View menu at the top, you can also change the zoom
level (just in case the default is too small or too large for you).

Many entries in the Sheet include notes, briefly explaining things
you should be aware of. Notes in Red refer to shortcuts that do
entirely different things in the 2 programs. Notes in Purple refer
to shortcuts that do not exist in any menu. The rest of the notes
just provide some extra info.

Moreover, entries with a Pale Orange background refer to shortcuts
that work ONLY when certain plugins are installed (they include
links to the required plugin).

Lastly, you can use Ctrl + F to search through the contents of the
Sheet. A small popup appears at the top right, letting you type in
the term(s) to be searched.

I have included a printable PDF version of the Sheet in the main
zip-file, but the on-line version will always get updated first.


MOUSE BINDINGS 
-------------------------------------------
file: controllerrc

MouseWheel Scroll Up = Zoom In
MouseWheel Scroll Dn = Zoom Out

The following are not Ps equivalents, but hopefully they will make
your life a little easier.

Alt + MouseWheel Scroll Up = Increase brush Size (by 10)
Alt + MouseWheel Scroll Dn = Decrease brush Size (by 10)

Ctrl + MouseWheel Scroll Up = Increase brush Hardness (by 10)
Ctrl + MouseWheel Scroll Dn = Decrease brush Hardness (by 10)

Shift + MouseWheel Scroll Up = Increase brush Angle (by 15 degrees)
Shift + MouseWheel Scroll Dn = Decrease brush Angle (by 10 degrees)


KEY BINDINGS (INCOMPATIBILITIES RATIONALE)
-------------------------------------------
file: menurc

For the complete list of more than 120 bindings check the on-line
Google Sheet:

	https://bit.ly/3dOJvka

In this section I will talk about some popular Photoshp shortcuts,
which (as of this writing) either do not have an exact match in
Gimp, or they require 3rd-party plugin(s), or they are mapped to
something entirely different. 

____________________________________________
The Undo/Redo Mess  (Step Backward, Step Forward, Toggle Last State)

For many decades, Adobe had this weird idea that Undo should
toggle on and off the last action, instead of walking down the
actions history, when the user was Undo'ing repeatedly. For the
latter, they had a different command: Step Backward (Ctrl+Alt+Z)
and to stay consistent with that weird idea, their Redo command
was called: Step Forward (Shift+Ctrl+Z)

The rest of the world was achieving the same things with just
2 simple commands: Undo and Redo

Starting with Ps 2019, Adobe finally decided to adopt common
sense, introducing proper Undo and Redo commands.

Redo works like their older "Step Forward" command, while Undo
now works like their old "Step Backward" command. The old Undo
functionality is now called "Toggle Last State" (Ctrl+Alt+Z).

I understand that many users of these bindings are probably used
to the old shortcuts of Ps, but I am purposely adopting the behavior
of recent Ps versions (which is a global standard anyway, since a
very long time, for every other Image Processor - Gimp included).

    Undo = Ctrl+Z
    Redo = Shift+Ctrl+Z

However, "Toggle Last State" (Ctrl+Alt+Z) does NOT exist in Gimp!

But Gimp has 2 hidden commands, which I am not sure if they are
still relevant. In any case, they do not appear in any menu, and I
have assigned them the following shortcuts:

    Strong Undo = Ctrl+Alt+Z
    Strong Redo = Shift+Ctrl+Alt+Z

Their native shortucts are Shift+Ctrl+Z and Shift+Ctrl+Y, respectively,
but the former is already assigned to Redo (so I re-bounded both).

In short, if you Undo via Ctrl+Alt+Z you may get away with it some
times, BUT not always. You should really get used to Undo with Ctrl+Z

____________________________________________
Main Keyboard vs Numeric Keypad

In Ps, most shortcuts containing numbers work no matter where
you input the numbers from (main keyboard of numeric keypad).

In Gimp it does matter, so keep it in mind and take a few minutes
to check the on-line Goggle Sheet for your favorite shortcuts that
include numbers.

For example, Ctrl+0 on the NUMERIC KEYPAD will "View->Zoom->Fit Image in Window". 
However, Ctrl+0 on the MAIN KEYBOARD does nothing.

In Ps, both of these shortcuts will "Zoom->Fit On Screen".

____________________________________________
Shift does NOT Cycle through Grouped Tools

In Ps, grouped tools share the same single-letter shortcut. The L
key for example, selects one of the grouped Lasso tools. By holding
down Shift while pressing L, you can cycle through them.

In Gimp, the same thing is done by hovering the mouse over a
tool and roll the mouse-wheel.

To somehow mimic Ps keyboard behavior, I assigned single-letter
shortcuts to most common tools, and for the rest in the group I
tried to assign the same letter combined with Shift, Ctrl and/or Alt.

For example, L selects the Free Selection tool, and Shift+L selects
the Scissors Select tool.

However, about half of the tools do NOT follow that rule, mostly
because Ps and Gimp work in different ways, they have different
tools, and even for common tools they group them differently.

Keep also in mind, that for Gimp tools that do NOT have similar
counterparts in Ps, I kept their default shortcuts.

Both programs allow Toolbar customization (including grouping)
but frankly I do not think it is a good idea. It would definitely
be a maintenance nightmare, plus I am not trying to convert Gimp
to a Ps clone! I rather try to ease a little the transition from
Ps to Gimp, without brutally tampering Gimp's uniqueness.

____________________________________________
Delete for Clear
Shift+Delete for Delete Layer
Shift+Backspace for Content Aware Fill (needs a plugin)

In Ps, and depending on the OS, Shift+Backspace and Shift+Delete
open the "Edit->Fill" dialog (which also opens with Shift+F5).

Shift+Delete in these bindings has been mapped to something
totally different: "Layer->Delete Layer"

That's because in Ps, the Delete button is context sensitive.
Without and active selection present, it deletes the current layer.
Else it behaves like "Edit->Clear", deleting just the contents of
the selection.

In Gimp I had to make a decision. Since Delete is Gimp's native
shortcut for "Edit->Clear", I left it intact and I assigned 
Shift+Delete to "Layer->Delete Layer".

Regarding Content Aware Fill, in earlier Ps versions it was just
an option inside the "Edit->Fill" dialog. Later versions improved
its functionality and introduced a separate entry in the Edit menu.

In Gimp, Content Aware Fill is done with a 3rd-party plugin, called:

    Resynthesizer: https://bit.ly/2Votn2o

The one I linked to works fine with Gimp 2.10.20 and it does lots of
nice things. Here we are interested in the "Heal Selection..." entry
which is added in the "Filters->Enhance" menu.

I have assigned the Shift+Backspace shortcut to it, which of course
works ONLY when the plugin is installed.

____________________________________________
Ctrl+J        for Layer via Copy (needs a plugin)
Shift+Ctrl+J  for Layer via Cut (needs a plugin)
Alt+J along with Ctrl+C/Ctrl+X for Gimp's native way
Shift+Ctrl+D  for Duplicate Layer

In Gimp there are no 1-command equivalents for Photoshop's
"Layer Via Copy" and "Layer Via Cut". But there are 2-command
equivalents.

In Ps, Ctrl+J is two-fold, depending on whether there is an active
selection present or not. If there is, it creates a new layer with
just a copy of the selection's contents. Else, it duplicates the
current layer.

In Gimp, if you want to just duplicate the current layer, use its
native shortcut: Shift+Ctrl+D

If you want a copy of the current selection as a new layer, use
these 2 shortcuts:
•  Ctrl+C  (Edit->Copy)
•  Alt+J   (Edit->Paste As->New Layer in Place)

Note that Alt+J is not a Gimp native shortcut, it is my doing.
So, in short, Ctrl+J gets mimicked by: Ctrl+C and then Alt+J

Back to Ps, Shift+Ctrl+J works only with an active selection present.
It creates a new layer with the selection's contents, but it deletes
them from the source layer.

With these bindings, in Gimp you get the same results by using
2 shortcuts:
•  Ctrl+X  (Edit->Cut)
•  Alt+J   (Edit->Paste As->New Layer in Place)

If you really can't live without Ctrl+J and Shift+Ctrl+J, you
can use the following Gimp plugin (works fine in Gimp 2.10.20):

    Layer via Cut/Copy: https://bit.ly/3dL3dx8

A "Layer via Copy" and a "Layer via Cut" entry are added at
the bottom of the "Layers" menu. My bindings assign Ctrl+J 
and Shift+Ctrl+J shortcuts to them regardless, but obviously
they work ONLY when the plugin is installed.

Keep also in mind that the plugin works ONLY when an active
selection is present.

____________________________________________
Ctrl+G       for Grouping layers
Ctrl+Alt+G   for Grouping linked layers (needs a plugin)
Shift+Ctrl+G for Un-grouping layers (needs a plugin)

In Ps, Ctrl+Alt+G toggles on and off the active clipping mask.

As of this writing, Gimp does not support clipping masks as an
1-command operation, hence this shortcut was free to be used
for something totally different!

Gimp's layer groups are currently quite primitive and although 
there is a "New Layer Group" command, there is NO "Ungroup Layers"
command (how crazy is that?)!

Furthermore, we can NOT select multiple layers in the layers panel,
meaning that any layer grouping/un-grouping has to be done
by moving around individual layers one by one!

There are a few 3rd-party plugins and scripts, trying to tackle
some of those issues. My personal choice is this script:

   Group Linked Layers: https://bit.ly/3i7ivzP

It adds 2 entries inside the right-click context menu and inside
the "Layer->Stack" menu, for which I have assigned the following
shortcuts:
•  Group Linked Layers  (Ctrl+Alt+G  #in Ps it toggles clipping mask)
•  Ungroup Layer  (Shift+Ctrl+G)

Obviously they work ONLY when that script is installed.

The expected Ctrl+G shortcut is assigned to Gimp's native
"Layer->New Layer Group".

____________________________________________
Ctrl+F       for Search
Ctrl+Alt+F   for Repeat Last Filter
Shift+Ctrl+F for Re-Show Last Filter

In Ps, for many years Ctrl+F was bound to "Filter->Last FIlter"
(which is also Gimp's default for the equivalent "Filters->Repeat Last").

At the same time, and although there was no menu entry for it,
Ctrl+Alt+F was opening the dialog of the last applied filter, so
users could change its parameters before re-applying it (Gimp
has "Filters->Re-Show" for the same thing).

However, starting with Ps 2017 an "Edit->Search" command was
introduced. It was assigned the Ctrl+F shortcut, while Ctrl+Alt+F
was assigned to "Filter->Repeat Last" (AFAIK its old functionality
was not assigned a new shortcut).

My Gimp bindings mimic the shortcuts of recent Ps versions, but
they also assign Shift+Ctrl+F to "Filters->Re-Show Last". In Ps,
this shortcut justifies a paragraph, which is of course totally
irrelevant, so keep that in mind.

____________________________________________
Cycling Through Open Documents
Ctrl+Tab
Ctrl+Page Up/Down
Alt+[0-9] (on main keyboard)

In Ps, Ctrl+Tab cycles through open documents.

However, I think that any Gimp shortcut involving a combination
of the Tab key with a modifier (like Ctrl, Shift, Alt, or any combo
of them) operates differently, depending on the operating system.

I'm not 100% sure for the above, but at least on Windows
Ctrl+Tab does NOT cycle through the open images (documents).

Actually the Gimp interface doesn't even allow me to assign
Ctrl+Tab to any command, so I edited manually the file itself.
It still doesn't work for me.

On a somewhat similar note, Ctrl+Page Up/Down have been
assigned to Scroll Page Left/Right, respectively, but they
act like Previous/Next Image instead (at least on Windows).

Anyway, to target an open image, you can use an Alt+[0-9]
shortcut. Just make sure you use the main keyboard (not
the numeric keypad).

____________________________________________
Shift+Ctrl+K (Color Settings / Color Management)

In Ps, Shift+Ctrl+K opens the Color Settings dialog, where you
can configure the Color Management defaults.

In Gimp, the corresponding dialog is not stand-alone, hence
we cannot have a shortcut for it.

You can access it by going to:

	Edit -> Preferences -> Color Management

If you are having trouble locating more of your favorite Ps Color
Management commands in Gimp (like "Edit->Assign Profile...",
"Edit->Convert to Profile...", etc), try the following menus:

	Image -> Color Management
	View -> Color Management


==========================================
BINDINGS CUSTOMIZATION
==========================================

Feel free to customize the bindings to your liking.

To change any key binding, first open the User Interface dialog:

	Edit -> Preferences -> Interface

Then, under the "Keyboard Shortcuts" section on the right, you
have several options. The important ones are the following:

•   The "Use dynamic keyboard shortcuts" Checkbox

    If you enable this, you can override existing shortcuts by
    simply opening any of Gimp's main menus (located at the top
    of the screen) then hover your mouse over any menu-entry,
    and press on your keyboard the new key combination you want
    for that entry.

    Fast & simple! The downside is that you do NOT get any warnings
    if the new binding exists already. It gets re-assigned slienlty.
    
•   The "Configure Keyboard Shortcuts" Button
    ( same as: Edit -> Keyboard Shortcuts..." )

    This will open a new dialog, with a tree-structured list of EVERY
    available command in Gimp (both visible and non-visible ones).
    You can navigate manually through the tree, but there is also
    a Search Filed at the top, where you can type in the names of
    specific commands.

    It is more cumbersome compared to the first method, but this
    one issues a warning every time you try to re-assign an existing
    shortcut, giving you the chance to change your mind.

See also the Gimp docs:

    https://docs.gimp.org/2.10/en/gimp-concepts-shortcuts.html

To change the mouse behavior is a bit more involved (not by much),
so I will just give you directly the link to the Gimp docs:

    https://docs.gimp.org/2.10/en/gimp-pimping.html#gimp-prefs-input-controllers


==========================================
SUPPORT, FIXES & FUTURE VERSIONS
==========================================

AFAIK, and as of this writing, these are the most comprehensive
and the most up to date Photoshop bindings for Gimp, available
anywhere.

Hopefully they will serve their purpose for at least all upcoming
2.x versions of Gimp, but let's be realistic: anyone switching from
Ps to Gimp will eventually end up using Gimp's native shortcuts.

I have put a great deal of effort making these bindings, and quite
frankly I do not intend to update them with every new version of
Gimp or Photoshop.

I do not rule out minor updates and fixes in the future, but in
general no guarantees.

Feel free to further customize the bindings to your liking (see
the BINDINGS CUSTOMIZATION section, above). If you release your
changes based on my work, remember to give me credit (see the
LICENSE text file, included in the bundle, for details).


==========================================
RELEASE HISTORY
==========================================

v0.1:
•	Initial Release (tested on Windows)